#' Print Method for an Object of Class `betamc`
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return Prints a matrix of estimates, standard errors,
#'   number of Monte Carlo replications, and confidence intervals.
#'
#' @param x Object of Class `betamc`,
#'   that is,
#'   the output of the
#'   [BetaMC()], [RSqMC()], [SCorMC()], [DeltaRSqMC()],
#'   [PCorMC()], [FSqMC()], or [DiffBetaMC()] functions.
#' @param alpha Numeric vector.
#'   Significance level \eqn{\alpha}.
#'   If `alpha = NULL`,
#'   use the argument `alpha` used in `x`.
#' @inheritParams summary.betamc
#'
#' @examples
#' # Data ---------------------------------------------------------------------
#' data("nas1982", package = "betaMC")
#'
#' # Fit Model in lm ----------------------------------------------------------
#' object <- stats::lm(
#'   formula = QUALITY ~ NARTIC + PCTGRT + PCTSUPP,
#'   data = nas1982
#' )
#'
#' # MC -----------------------------------------------------------------------
#' mc <- MC(
#'   object = object,
#'   R = 100, # use a large value e.g., 20000L for actual research
#'   seed = 0508
#' )
#'
#' # BetaMC -------------------------------------------------------------------
#' out <- BetaMC(object = mc, alpha = 0.05)
#'
#' ## Methods -----------------------------------------------------------------
#' print(x = out)
#'
#' @keywords methods
#' @export
print.betamc <- function(x,
                         alpha = NULL,
                         digits = 4,
                         ...) {
  print.summary.betamc(
    x = summary.betamc(
      object = x,
      alpha = alpha,
      digits = digits
    )
  )
}

#' Summary Method for an Object of Class `betamc`
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @details
#' The confidence intervals are percentile intervals,
#' \eqn{\left[ \hat{G}^{-1} \left( \alpha / 2 \right), \hat{G}^{-1} \left( 1 -
#' \alpha / 2 \right) \right]},
#' where \eqn{\hat{G}} is the empirical distribution function of the Monte
#' Carlo draws (type 7 quantiles).
#' The standard errors are the standard deviations of the draws.
#'
#' @return Returns a matrix of
#'   estimates,
#'   standard errors,
#'   number of Monte Carlo replications,
#'   and
#'   confidence intervals.
#'
#' @param object Object of Class `betamc`,
#'   that is,
#'   the output of the
#'   [BetaMC()], [RSqMC()], [SCorMC()], [DeltaRSqMC()],
#'   [PCorMC()], [FSqMC()], or [DiffBetaMC()] functions.
#' @param ... additional arguments.
#' @param alpha Numeric vector.
#'   Significance level \eqn{\alpha}.
#'   If `alpha = NULL`,
#'   use the argument `alpha` used in `object`.
#' @param digits Digits to print.
#'
#' @examples
#' # Data ---------------------------------------------------------------------
#' data("nas1982", package = "betaMC")
#'
#' # Fit Model in lm ----------------------------------------------------------
#' object <- stats::lm(
#'   formula = QUALITY ~ NARTIC + PCTGRT + PCTSUPP,
#'   data = nas1982
#' )
#'
#' # MC -----------------------------------------------------------------------
#' mc <- MC(
#'   object = object,
#'   R = 100, # use a large value e.g., 20000L for actual research
#'   seed = 0508
#' )
#'
#' # BetaMC -------------------------------------------------------------------
#' out <- BetaMC(object = mc, alpha = 0.05)
#'
#' ## Methods -----------------------------------------------------------------
#' summary(object = out)
#'
#' @keywords methods
#' @export
summary.betamc <- function(object,
                           alpha = NULL,
                           digits = 4,
                           ...) {
  ci <- .CI(
    object = object,
    alpha = alpha
  )
  print_summary <- round(
    x = ci,
    digits = digits
  )
  attr(
    x = ci,
    which = "fit"
  ) <- object
  attr(
    x = ci,
    which = "print_summary"
  ) <- print_summary
  attr(
    x = ci,
    which = "alpha"
  ) <- alpha
  attr(
    x = ci,
    which = "digits"
  ) <- digits
  class(x = ci) <- "summary.betamc"
  ci
}

#' @noRd
#' @keywords internal
#' @exportS3Method print summary.betamc
print.summary.betamc <- function(x,
                                 ...) {
  print_summary <- attr(
    x = x,
    which = "print_summary"
  )
  object <- attr(
    x = x,
    which = "fit"
  )
  type <- object$args$object$args$type
  if (object$fun == "BetaMC") {
    label <- "Standardized regression slopes"
  }
  if (object$fun == "RSqMC") {
    label <- "R-squared and adjusted R-squared"
  }
  if (object$fun == "SCorMC") {
    label <- "Semipartial correlations"
  }
  if (object$fun == "DeltaRSqMC") {
    label <- "Improvement in R-squared"
  }
  if (object$fun == "PCorMC") {
    label <- "Squared partial correlations"
  }
  if (object$fun == "DiffBetaMC") {
    label <- "Differences of standardized regression slopes"
  }
  if (object$fun == "FSqMC") {
    label <- "Cohen's f-squared (fsq) and local f-squared"
  }
  cat("Call:\n")
  base::print(x = object$call)
  cat(
    paste0(
      "\n",
      label,
      "\n",
      "type = ",
      "\"",
      type,
      "\"",
      "\n"
    )
  )
  print(x = print_summary)
  invisible(x = x)
}

#' Sampling Variance-Covariance Matrix Method for an Object of Class `betamc`
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return Returns the variance-covariance matrix of estimates.
#'
#' @inheritParams summary.betamc
#'
#' @examples
#' # Data ---------------------------------------------------------------------
#' data("nas1982", package = "betaMC")
#'
#' # Fit Model in lm ----------------------------------------------------------
#' object <- stats::lm(
#'   formula = QUALITY ~ NARTIC + PCTGRT + PCTSUPP,
#'   data = nas1982
#' )
#'
#' # MC -----------------------------------------------------------------------
#' mc <- MC(
#'   object = object,
#'   R = 100, # use a large value e.g., 20000L for actual research
#'   seed = 0508
#' )
#'
#' # BetaMC -------------------------------------------------------------------
#' out <- BetaMC(object = mc, alpha = 0.05)
#'
#' ## Methods -----------------------------------------------------------------
#' vcov(object = out)
#'
#' @keywords methods
#' @export
vcov.betamc <- function(object,
                        ...) {
  thetahatstar <- unname(
    obj = as.matrix(x = object$thetahatstar)
  )
  colnames(x = thetahatstar) <- names(x = object$est)
  stats::var(x = thetahatstar)
}

#' Estimated Parameter Method for an Object of Class `betamc`
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return Returns a vector of estimated parameters.
#'
#' @inheritParams summary.betamc
#'
#' @examples
#' # Data ---------------------------------------------------------------------
#' data("nas1982", package = "betaMC")
#'
#' # Fit Model in lm ----------------------------------------------------------
#' object <- stats::lm(
#'   formula = QUALITY ~ NARTIC + PCTGRT + PCTSUPP,
#'   data = nas1982
#' )
#'
#' # MC -----------------------------------------------------------------------
#' mc <- MC(
#'   object = object,
#'   R = 100, # use a large value e.g., 20000L for actual research
#'   seed = 0508
#' )
#'
#' # BetaMC -------------------------------------------------------------------
#' out <- BetaMC(object = mc, alpha = 0.05)
#'
#' ## Methods -----------------------------------------------------------------
#' coef(object = out)
#'
#' @keywords methods
#' @export
coef.betamc <- function(object,
                        ...) {
  object$est
}

#' Confidence Intervals Method for an Object of Class `betamc`
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return Returns a matrix of confidence intervals.
#'
#' @inherit summary.betamc details
#'
#' @inheritParams summary.betamc
#' @param parm a specification of which parameters
#'   are to be given confidence intervals,
#'   either a vector of numbers or a vector of names.
#'   If missing, all parameters are considered.
#' @param level the confidence level required.
#'
#' @examples
#' # Data ---------------------------------------------------------------------
#' data("nas1982", package = "betaMC")
#'
#' # Fit Model in lm ----------------------------------------------------------
#' object <- stats::lm(
#'   formula = QUALITY ~ NARTIC + PCTGRT + PCTSUPP,
#'   data = nas1982
#' )
#'
#' # MC -----------------------------------------------------------------------
#' mc <- MC(
#'   object = object,
#'   R = 100, # use a large value e.g., 20000L for actual research
#'   seed = 0508
#' )
#'
#' # BetaMC -------------------------------------------------------------------
#' out <- BetaMC(object = mc, alpha = 0.05)
#'
#' ## Methods -----------------------------------------------------------------
#' confint(object = out, level = 0.95)
#'
#' @keywords methods
#' @export
confint.betamc <- function(object,
                           parm = NULL,
                           level = 0.95,
                           ...) {
  if (is.null(x = parm)) {
    parm <- seq_along(
      along.with = object$est
    )
  }
  ci <- .CI(
    object = object,
    alpha = 1 - level[1]
  )[parm, 4:5, drop = FALSE]
  varnames <- colnames(x = ci)
  varnames <- gsub(
    pattern = "%",
    replacement = " %",
    x = varnames
  )
  colnames(x = ci) <- varnames
  ci
}
