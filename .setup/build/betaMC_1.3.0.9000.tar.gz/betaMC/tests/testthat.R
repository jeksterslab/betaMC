library(testthat)
library(betaMC)

test_check("betaMC")
