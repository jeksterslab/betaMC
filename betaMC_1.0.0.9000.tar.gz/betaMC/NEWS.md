# betaMC 1.0.0.9000

Latest development version.

* Added the `DiffBetaMC()`, the `RSqBetaMC()`, and the `PCorBetaMC()` functions.

# betaMC 1.0.0

## Major

* And so it begins.
